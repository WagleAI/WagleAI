package com.sample.mask;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button mapBtn;
    ImageView imgFace;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);

        mapBtn = (Button)findViewById(R.id.mapBtn);
        imgFace = (ImageView)findViewById(R.id.showImg);


        mapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                imgFace.setImageResource(R.drawable.sorryface);
            }
        });
    }
}
